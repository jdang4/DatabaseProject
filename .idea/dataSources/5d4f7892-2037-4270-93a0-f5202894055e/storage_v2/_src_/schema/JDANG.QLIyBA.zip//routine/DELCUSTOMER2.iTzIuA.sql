create procedure DelCustomer2 (firstName varchar2, lastName varchar2) IS
    Begin
        delete from Customer
        where customer.firstName = DelCustomer2.firstName 
            and customer.lastName = DelCustomer2.lastName;
    End DelCustomer2;
/

