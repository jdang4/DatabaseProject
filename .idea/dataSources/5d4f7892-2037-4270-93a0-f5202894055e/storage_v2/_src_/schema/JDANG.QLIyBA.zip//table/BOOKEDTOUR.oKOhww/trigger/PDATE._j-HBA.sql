create trigger PDATE
  before insert
  on BOOKEDTOUR
  for each row
Declare tempDate Date;
Begin
    select sysdate into tempDate from Dual;
    :new.PurchaseDate := sysdate + 90;
End;
/

