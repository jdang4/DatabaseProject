create trigger TESTLIKE
  before insert
  on BOOKLIT
  for each row
Begin
	if (:new.title Like '%of the%') then
	:new.Price := :new.Price + 500;
	end if;
End;
/

