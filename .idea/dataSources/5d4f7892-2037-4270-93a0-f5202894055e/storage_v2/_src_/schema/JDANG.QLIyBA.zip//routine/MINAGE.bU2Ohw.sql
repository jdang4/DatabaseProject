create function minAge return number is
  tempAge number;
begin
  select min(Age) into tempAge
  from customer;
  return (tempAge);
end;
/

