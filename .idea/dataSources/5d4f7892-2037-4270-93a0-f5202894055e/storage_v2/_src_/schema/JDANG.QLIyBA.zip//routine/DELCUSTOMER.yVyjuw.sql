create procedure DelCustomer (CustomerID number) IS
    Begin
        delete from Customer
        where customer.customerID = DelCustomer.CustomerID;
    End DelCustomer;
/

