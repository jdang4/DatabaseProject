create procedure findTitle (accounN in varchar2) is
    myTitle varchar2(25);
    cursor C1 is
        select title 
        from StaffTitle join Title on StaffTitle.acronym = Title.acronym
        where accountName = accounN;

begin
    for rec in C1 loop
        myTitle := rec.title;
    end loop;

    dbms_output.put_line('Title: ' || myTitle);
end;
/

