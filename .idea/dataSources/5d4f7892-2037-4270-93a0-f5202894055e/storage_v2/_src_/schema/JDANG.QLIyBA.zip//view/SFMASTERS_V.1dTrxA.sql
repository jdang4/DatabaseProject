create view SFMASTERS_V as
select "ISBN","FIRSTNAME","LASTNAME","TITLE","COPYRIGHT","PRICE","PUBID"
from SFBook
where lastName = 'Asimov' or lastName = 'Heinlein'
/

