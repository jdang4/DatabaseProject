create trigger CHANGEPRICES
  after insert
  on SFBOOK
begin
	update SFBook
	set Price = Price + 100
	where Copyright < 1970;
    dbms_output.put_line('hello');
end;
/

