create procedure SurgeonOperations (S_fName IN varchar2, S_lName IN varchar2) IS
    operationNum NUMBER;
    CURSOR C1 IS
        select D.firstName, D.lastName, S.physicianID
        from Doctor D join Surgeon S on D.physicianID = S.physicianID join Operation O on O.physicianID = S.physicianID
        where D.firstName = S_fName AND D.lastName = S_lName AND S."ROLE" = 'Surgeon';

    BEGIN
        for record in C1 LOOP
            operationNum := C1%ROWCOUNT;
        END LOOP;

        IF operationNum is NULL THEN
            raise no_data_found;
        End IF;

        dbms_output.put_line('Dr.' || S_fName || ' ' || S_lName || ': ' || operationNum || ' operations');
        EXCEPTION
            WHEN no_data_found THEN
                raise_application_error(-20001, 'An error was encountered - '|| SQLCODE ||' -ERROR-' || SQLERRM);

    END SurgeonOperations;
/

