create view MATCHINGBLOODTYPES as
select op.organtype, O.bloodType, COUNT(P.healthCareID) as sumPatients
    from Organ O 
    join Patient P on O.bloodType = P.bloodType 
    join OP on OP.physicianid = o.physicianid
    group by rollup(op.organtype, o.bloodType)
    order by organtype, bloodType
/

