create trigger CHECKBUS
  before insert or update
  on VEHICLE
  for each row
declare 
    Cursor Bus1 IS
        select VehicleType, Year
        from Vehicle;
Begin
    -- tests any record being inserted
    if (:new.VehicleType = 'bus' AND :new.Year < 2010) then
        RAISE_APPLICATION_ERROR(-20003, 'Inserted Row Error: Bus must be newer than 2010');
    end if;

    for vehicleRow in Bus1 Loop
        if (vehicleRow.VehicleType = 'bus' and vehicleRow.Year < 2015) then
            RAISE_APPLICATION_ERROR(-20003, 'Inserted Row Error: Existing Bus must be newer than 2015');
        end if;
    end loop;
End;
/

